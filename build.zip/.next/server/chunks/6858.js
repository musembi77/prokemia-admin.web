"use strict";
exports.id = 6858;
exports.ids = [6858];
exports.modules = {

/***/ 6858:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_api_clients_suspend_client_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8874);
/* harmony import */ var _pages_api_distributors_suspend_distributor_account__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5569);
/* harmony import */ var _pages_api_manufacturers_suspend_manufacturer_account__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1129);
/* harmony import */ var _pages_api_salespeople_suspend_salesperson_account__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2897);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_clients_suspend_client_account__WEBPACK_IMPORTED_MODULE_4__, _pages_api_distributors_suspend_distributor_account__WEBPACK_IMPORTED_MODULE_5__, _pages_api_manufacturers_suspend_manufacturer_account__WEBPACK_IMPORTED_MODULE_6__, _pages_api_salespeople_suspend_salesperson_account__WEBPACK_IMPORTED_MODULE_7__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_clients_suspend_client_account__WEBPACK_IMPORTED_MODULE_4__, _pages_api_distributors_suspend_distributor_account__WEBPACK_IMPORTED_MODULE_5__, _pages_api_manufacturers_suspend_manufacturer_account__WEBPACK_IMPORTED_MODULE_6__, _pages_api_salespeople_suspend_salesperson_account__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function SuspendAccountModal({ issuspendModalvisible , setissuspendModalvisible , distributor_data , manufacturer_data , client_data , salesperson_data , acc_type , payload  }) {
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useToast)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_8___default())();
    //console.log(isaddingreviewgModalvisible);
    const HandleModalOpen = ()=>{
        if (issuspendModalvisible !== true) {
        //console.log('damn')
        } else {
            onOpen();
            setissuspendModalvisible(false);
        }
    };
    const { 0: confirm_name , 1: set_confirm_name  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: name , 1: set_name  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: auth_role , 1: set_auth_role  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        HandleModalOpen();
        if (acc_type === "client") {
            set_name(client_data?.first_name);
        }
        if (acc_type === "distributors") {
            set_name(distributor_data?.company_name);
        }
        if (acc_type === "manufacturers") {
            set_name(manufacturer_data?.company_name);
        }
        if (acc_type === "salespersons") {
            set_name(salesperson_data?.first_name);
        }
    }, [
        issuspendModalvisible
    ]);
    const handle_suspension = async ()=>{
        if (confirm_name === name) {
            if (acc_type === "client") {
                await (0,_pages_api_clients_suspend_client_account__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(payload).then(()=>{
                    toast({
                        title: "",
                        description: `${name} account has been suspended`,
                        status: "info",
                        isClosable: true
                    });
                }).catch((err)=>{
                    console.log(err);
                    toast({
                        title: "Error while suspending account",
                        description: err?.response?.data,
                        status: "error",
                        isClosable: true
                    });
                });
            } else if (acc_type === "distributors") {
                await (0,_pages_api_distributors_suspend_distributor_account__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(payload).then(()=>{
                    toast({
                        title: "",
                        description: `${name} account has been suspended`,
                        status: "info",
                        isClosable: true
                    });
                }).catch((err)=>{
                    toast({
                        title: "",
                        description: err.response.data,
                        status: "error",
                        isClosable: true
                    });
                });
            } else if (acc_type === "manufacturers") {
                await (0,_pages_api_manufacturers_suspend_manufacturer_account__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(payload).then(()=>{
                    toast({
                        title: "",
                        description: `${name} account has been suspended`,
                        status: "info",
                        isClosable: true
                    });
                }).catch((err)=>{
                    toast({
                        title: "",
                        description: err.response.data,
                        status: "error",
                        isClosable: true
                    });
                });
            } else if (acc_type === "salespersons") await (0,_pages_api_salespeople_suspend_salesperson_account__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(payload).then(()=>{
                toast({
                    title: "",
                    description: `${name} account has been suspended`,
                    status: "info",
                    isClosable: true
                });
            }).catch((err)=>{
                toast({
                    title: "",
                    description: err.response.data,
                    status: "error",
                    isClosable: true
                });
            });
        } else {
            toast({
                title: "",
                description: "the name of the accounts do not match,try again",
                status: "info",
                isClosable: true
            });
        }
        onClose();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
            isOpen: isOpen,
            onClose: onClose,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalHeader, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: "24px",
                                color: "red",
                                children: "Suspend Account"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalCloseButton, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                spacing: 4,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        children: "By suspending this account, the user will not have access to use the service and the platform."
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        children: [
                                            "Enter the name of Account Holder: ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                style: {
                                                    color: "red"
                                                },
                                                children: name
                                            }),
                                            " below, to complete suspension."
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                            type: "text",
                                            placeholder: "name of account Holder",
                                            variant: "filled",
                                            onChange: (e)=>{
                                                set_confirm_name(e.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        bg: "red",
                                        borderRadius: "0",
                                        color: "#fff",
                                        onClick: handle_suspension,
                                        children: "Suspend"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SuspendAccountModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8874:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Suspend_Client)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Suspend_Client(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/suspend_client_account", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/suspend_client_account`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5569:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Suspend_Distributor)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Suspend_Distributor(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/suspend_distributor_account", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://prokemia-adminserver-production.up.railway.app/api/suspend_distributor_account", payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1129:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Suspend_Manufacturer)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Suspend_Manufacturer(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/suspend_manufacturer_account", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://prokemia-adminserver-production.up.railway.app/api/suspend_manufacturer_account", payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2897:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Suspend_Salesperson)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Suspend_Salesperson(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/suspend_salesperson_account", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://prokemia-adminserver-production.up.railway.app/api/suspend_salesperson_account", payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;