"use strict";
exports.id = 3140;
exports.ids = [3140];
exports.modules = {

/***/ 5076:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Delete_Product_Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_Products_delete_product_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2251);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_Products_delete_product_js__WEBPACK_IMPORTED_MODULE_3__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_Products_delete_product_js__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_5___default())();
let token = cookies.get("admin_token");
function Delete_Product_Modal({ is_delete_product_Modalvisible , set_is_delete_product_Modalvisible , product_data  }) {
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    const { 0: name , 1: set_name  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useToast)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_5___default())();
    let token = cookies.get("admin_token");
    const { 0: auth_role , 1: set_auth_role  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    //console.log(isaddingreviewgModalvisible);
    const HandleModalOpen = ()=>{
        if (is_delete_product_Modalvisible !== true) {
        //console.log('damn')
        } else {
            onOpen();
            set_is_delete_product_Modalvisible(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        HandleModalOpen();
        if (!token) {
            toast({
                title: "",
                description: `You need to signed in, to have access`,
                status: "info",
                isClosable: true
            });
            router.push("/");
        } else {
            let decoded = jwt_decode__WEBPACK_IMPORTED_MODULE_6___default()(token);
            //console.log(decoded);
            set_auth_role(decoded?.role);
        }
    }, [
        is_delete_product_Modalvisible
    ]);
    // }
    const handle_Delete_Product = async ()=>{
        //console.log(product_data?.name_of_product,name)
        if (product_data?.name_of_product === name) {
            const payload = {
                _id: product_data?._id,
                auth_role
            };
            await (0,_pages_api_Products_delete_product_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(payload).then(()=>{
                toast({
                    title: "",
                    description: `${product_data?.name_of_product} has been deleted`,
                    status: "success",
                    isClosable: true
                });
                router.back();
            }).catch((err)=>{
                console.log(err);
                toast({
                    title: "",
                    description: err.response?.data,
                    status: "error",
                    isClosable: true
                });
            });
        } else {
            toast({
                title: "",
                description: `Enter the correct product name to complete deletion`,
                status: "info",
                isClosable: true
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
            isOpen: isOpen,
            onClose: onClose,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalHeader, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: "24px",
                                color: "red",
                                children: "Delete Product"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalCloseButton, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                spacing: 4,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        children: "By Deleting this product,the information of the product will be permanently erased."
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        children: [
                                            "Enter the name of Product below,",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                style: {
                                                    color: "red",
                                                    padding: "5px",
                                                    backgroundColor: "#eee"
                                                },
                                                children: product_data?.name_of_product
                                            }),
                                            " to complete deletion."
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                            type: "text",
                                            placeholder: "name of product",
                                            variant: "filled",
                                            onChange: (e)=>{
                                                set_name(e.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        bg: "red",
                                        borderRadius: "0",
                                        color: "#fff",
                                        onClick: handle_Delete_Product,
                                        children: "Delete Product"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1742:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Approve_Product)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

//import Cookies from 'universal-cookie';
async function Approve_Product(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/approve_product", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://prokemia-adminserver-production.up.railway.app/api/approve_product", payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2251:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Delete_Product)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

//import Cookies from 'universal-cookie';
async function Delete_Product(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/delete_product", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://prokemia-adminserver-production.up.railway.app/api/delete_product", payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;