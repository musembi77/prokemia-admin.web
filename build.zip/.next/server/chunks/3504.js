exports.id = 3504;
exports.ids = [3504];
exports.modules = {

/***/ 9689:
/***/ ((module) => {

// Exports
module.exports = {
	"AuthBody": "Auth_AuthBody__J2FU8",
	"Auth_Image": "Auth_Auth_Image__vyQpA",
	"Back_Icon": "Auth_Back_Icon__EO4Vp",
	"Auth_Links": "Auth_Auth_Links__vee4Q",
	"Form_Body": "Auth_Form_Body__Mh_I7",
	"Form": "Auth_Form__Du8EG"
};


/***/ }),

/***/ 4461:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Loading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__]);
_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Loading({ width , height , color  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_2___default()), {
                src: "https://cdn.lordicon.com/bhenfmcm.js"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                src: "https://cdn.lordicon.com/xjovhxra.json",
                trigger: "loop",
                colors: `primary:${color},secondary:#ffffff`,
                stroke: "40",
                style: {
                    width: width,
                    height: height
                }
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3504:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AuthHandler)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var _styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9689);
/* harmony import */ var _styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_auth_signin_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6444);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Loading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _api_auth_signin_js__WEBPACK_IMPORTED_MODULE_5__, _components_Loading__WEBPACK_IMPORTED_MODULE_7__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _api_auth_signin_js__WEBPACK_IMPORTED_MODULE_5__, _components_Loading__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function AuthHandler() {
    /**
	 * Handles user sign in
	 * 
	 */ const { 0: show , 1: setShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleClick = ()=>setShow(!show);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const { 0: user_password , 1: set_user_password  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: user_name , 1: setuser_name  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: window , 1: setwindow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: is_loading , 1: set_is_loading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_6___default())();
    let token = cookies.get("admin_token");
    const payload = {
        user_name,
        user_password
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const client = {
            width: document.documentElement.clientWidth,
            height: document.documentElement.clientHeight
        };
        //console.log(client.width)
        if (client.width > 500) {
            setwindow(true);
        }
        if (token) {
            router.push("/dashboard");
            return;
        }
    }, [
        token
    ]);
    const handleSignIn = async (event)=>{
        set_is_loading(true);
        /**
		 * Handles user sign in.
		 * 
		 * user_password (any): password for the user.
		 * user_name (String): name for user.
		 * paylaod (obj): user credentials. 
		 * token (string): jwt user token.
		 * 
		 * Return:
		 *  	redirects to dashboard on success else
		 * 			alerts an error.
		 */ //console.log(payload)
        event.preventDefault();
        if (user_password === "" || user_name === "") {
            toast({
                title: "",
                description: "All inputs are required",
                status: "info",
                isClosable: true
            });
        } else {
            await (0,_api_auth_signin_js__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(payload).then((response)=>{
                //console.log(response)
                if (response.status === 200) {
                    toast({
                        title: "",
                        description: "Successfully Logged in",
                        status: "success",
                        isClosable: true
                    });
                    setTimeout(()=>{}, 6000);
                    router.push("/dashboard");
                    return;
                } else {
                    return toast({
                        title: "Error logging in",
                        description: response.data,
                        status: "error",
                        isClosable: true
                    });
                }
            }).catch((err)=>{
                return toast({
                    title: "Error logging in",
                    description: "",
                    status: "error",
                    isClosable: true
                });
            }).finally(()=>{
                setTimeout(()=>{
                    set_is_loading(false);
                }, 3000);
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        className: (_styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8___default().AuthBody),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8___default().Auth_Image)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                className: (_styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8___default().Form_Body),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                    className: (_styles_Auth_module_css__WEBPACK_IMPORTED_MODULE_8___default().Form),
                    gap: "3",
                    direction: "column",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                            as: "h2",
                            mb: "0",
                            onClick: ()=>{
                                router.push("/");
                            },
                            fontSize: "28px",
                            color: "#00e0c6",
                            children: [
                                "Pro",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        color: "#000"
                                    },
                                    children: "Kemia"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        fontSize: "16px",
                                        color: "grey",
                                        marginTop: "17px"
                                    },
                                    children: ".admin"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                            as: "h6",
                            fontWeight: "bold",
                            children: "SignIn "
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            direction: "column",
                            gap: "2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    fontWeight: "bold",
                                    children: "Username"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                    required: true,
                                    type: "text",
                                    placeholder: "Username",
                                    variant: "filled",
                                    onChange: (e)=>{
                                        setuser_name(e.target.value);
                                    }
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontWeight: "bold",
                            children: "Password"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.InputGroup, {
                            size: "md",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                    pr: "4.5rem",
                                    type: show ? "text" : "password",
                                    placeholder: "Enter password",
                                    variant: "filled",
                                    onChange: (e)=>{
                                        set_user_password(e.target.value);
                                    },
                                    required: true
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.InputRightElement, {
                                    width: "4.5rem",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                        h: "1.75rem",
                                        size: "sm",
                                        onClick: handleClick,
                                        bg: "#fff",
                                        children: show ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.VisibilityOff, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Visibility, {})
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            type: "submit",
                            onClick: handleSignIn,
                            bg: "#009393",
                            color: "#fff",
                            disabled: is_loading ? true : false,
                            align: "center",
                            children: [
                                is_loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    width: "40px",
                                    height: "40px",
                                    color: "#ffffff"
                                }) : null,
                                is_loading ? "signing in..." : "Sign in"
                            ]
                        })
                    ]
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6444:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SignIn)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function SignIn(payload) {
    /**
     * Sends a post req to submit user credentials to verify user.
     * 
     * env (): state of project.
     * result (obj): json res containing the token and status from server.
     * 
     * Return :
     *      Returns the result to Authhandler.
     * 
     */ const env = "production";
    //console.log(env)
    if (env == "development") {
        const end_point = process.env.DEV_API_ENDPOINT;
        const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_1___default())();
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`http://localhost:5001/api/signin`, payload);
        if (result.status === 201 || result.status === 500) {
            return result;
        } else {
            //console.log(result.data)
            cookies.set("admin_token", result.data, {
                path: "/"
            });
            return result;
        }
    } else if (env == "production") {
        const cookies1 = new (universal_cookie__WEBPACK_IMPORTED_MODULE_1___default())();
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/signin`, payload);
        if (result1.status === 201 || result1.status === 500) {
            return result1;
        } else {
            //console.log(result.data)
            cookies1.set("admin_token", result1.data, {
                path: "/"
            });
            return result1;
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;