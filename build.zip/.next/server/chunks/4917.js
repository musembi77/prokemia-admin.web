exports.id = 4917;
exports.ids = [4917];
exports.modules = {

/***/ 324:
/***/ ((module) => {

// Exports
module.exports = {
	"page_infomation_details_Body": "Permissions_Accounts_page_infomation_details_Body__mbvia",
	"page_infomation_details_Description": "Permissions_Accounts_page_infomation_details_Description__MZkVa",
	"page_infomation_details_Title": "Permissions_Accounts_page_infomation_details_Title__9xSxu",
	"page_infomation_details_Search": "Permissions_Accounts_page_infomation_details_Search__ioPFn",
	"fetched_data_body": "Permissions_Accounts_fetched_data_body__sEPFz",
	"fetched_data_container": "Permissions_Accounts_fetched_data_container__n6Dw1",
	"user_card_item_body": "Permissions_Accounts_user_card_item_body__WrPhF",
	"user_card_item_control": "Permissions_Accounts_user_card_item_control__ym4yk",
	"role_card_item_body": "Permissions_Accounts_role_card_item_body__DoiYG"
};


/***/ }),

/***/ 4650:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_auth_delete_admin_account_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9768);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_auth_delete_admin_account_js__WEBPACK_IMPORTED_MODULE_3__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_auth_delete_admin_account_js__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function RemoveAdminModal({ isremoveModalvisible , setisremoveModalvisible , admin_data  }) {
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useToast)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_4___default())();
    let token = cookies.get("admin_token");
    ////console.log(isaddingreviewgModalvisible);
    const HandleModalOpen = ()=>{
        if (isremoveModalvisible !== true) {
        ////console.log('damn')
        } else {
            onOpen();
            setisremoveModalvisible(false);
        }
    };
    const { 0: auth_role , 1: set_auth_role  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        HandleModalOpen();
        if (!token) {
            toast({
                title: "",
                description: `You need to signed in, to have access`,
                status: "info",
                isClosable: true
            });
            router.push("/");
        } else {
            let decoded = jwt_decode__WEBPACK_IMPORTED_MODULE_5___default()(token);
            //console.log(decoded);
            set_auth_role(decoded?.role);
        }
    }, [
        isremoveModalvisible
    ]);
    const { 0: confirm_name , 1: set_confirm_name  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: name , 1: set_name  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const payload = {
        _id: admin_data?._id,
        auth_role
    };
    const handle_delete_admin_account = async ()=>{
        //console.log(payload)
        if (confirm_name === admin_data?.user_name) {
            await (0,_pages_api_auth_delete_admin_account_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(payload).then(()=>{
                toast({
                    title: "",
                    description: `${admin_data?.user_name} account has been deleted`,
                    status: "info",
                    isClosable: true
                });
                router.reload();
            }).catch((err)=>{
                console.log(err);
                toast({
                    title: "",
                    description: err.response.data,
                    status: "error",
                    isClosable: true
                });
            });
        } else {
            toast({
                title: "",
                description: "Enter the right name to delete this account",
                status: "error",
                isClosable: true
            });
        }
        onClose();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
            isOpen: isOpen,
            onClose: onClose,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalHeader, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: "24px",
                                color: "red",
                                children: "Remove Admin Account"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalCloseButton, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                spacing: 4,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        children: "By removing this account, the user will not have access to use the service and the platform."
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        children: [
                                            "Enter the name of Account Holder: ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                style: {
                                                    color: "red"
                                                },
                                                children: admin_data?.user_name
                                            }),
                                            " below, to complete deletion."
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                            type: "text",
                                            placeholder: "name of user",
                                            variant: "filled",
                                            onChange: (e)=>{
                                                set_confirm_name(e.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        bg: "red",
                                        borderRadius: "0",
                                        color: "#fff",
                                        onClick: handle_delete_admin_account,
                                        children: "Remove"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveAdminModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7431:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Get_Roles)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Get_Roles(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("http://localhost:5001/api/get_roles");
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://prokemia-adminserver-production.up.railway.app/api/get_roles`);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9768:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Delete_Admin_Account)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Delete_Admin_Account(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/delete_admin_user", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/delete_admin_user`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;