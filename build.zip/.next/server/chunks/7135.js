"use strict";
exports.id = 7135;
exports.ids = [7135];
exports.modules = {

/***/ 1384:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_DoneAllOutlined__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2914);
/* harmony import */ var _mui_icons_material_DoneAllOutlined__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DoneAllOutlined__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__]);
_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Product({ item  }) {
    const router = useRouter();
    return /*#__PURE__*/ _jsxs(Flex, {
        boxShadow: "lg",
        bg: "#fff",
        borderRadius: "5px",
        direction: "column",
        m: "2",
        w: "350px",
        position: "relative",
        h: "350px",
        justify: "space-between",
        children: [
            /*#__PURE__*/ _jsxs(Flex, {
                p: "2",
                direction: "column",
                w: "100%",
                gap: "2",
                children: [
                    /*#__PURE__*/ _jsx(Text, {
                        color: "#009393",
                        fontWeight: "bold",
                        fontSize: "24px",
                        w: "100%",
                        children: item?.name_of_product
                    }),
                    /*#__PURE__*/ _jsxs(Flex, {
                        direction: "column",
                        children: [
                            /*#__PURE__*/ _jsx(Text, {
                                fontWeight: "bold",
                                children: "Industry:"
                            }),
                            /*#__PURE__*/ _jsx(Text, {
                                children: item?.industry
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsxs(Flex, {
                        direction: "column",
                        children: [
                            /*#__PURE__*/ _jsx(Text, {
                                fontWeight: "bold",
                                children: "Technology:"
                            }),
                            /*#__PURE__*/ _jsx(Text, {
                                children: item?.technology
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsxs(Flex, {
                        direction: "column",
                        children: [
                            /*#__PURE__*/ _jsx(Text, {
                                fontWeight: "bold",
                                children: "Brand:"
                            }),
                            /*#__PURE__*/ _jsx(Text, {
                                children: item?.brand
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsxs(Flex, {
                        direction: "column",
                        children: [
                            /*#__PURE__*/ _jsx(Text, {
                                fontWeight: "bold",
                                children: "Manufactured by:"
                            }),
                            /*#__PURE__*/ _jsx(Text, {
                                children: item?.manufactured_by
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsx(Button, {
                m: "1",
                color: "#fff",
                bg: "#009393",
                p: "1",
                cursor: "pointer",
                onClick: ()=>{
                    router.push(`/product/${item?._id}`);
                },
                border: "1px solid #009393",
                children: "View product"
            })
        ]
    });
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Product)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6866:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Get_Products)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

//import Cookies from 'universal-cookie';
async function Get_Products() {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("http://localhost:5001/api/get_products");
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://prokemia-adminserver-production.up.railway.app/api/get_products");
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;