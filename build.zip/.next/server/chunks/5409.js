"use strict";
exports.id = 5409;
exports.ids = [5409];
exports.modules = {

/***/ 4739:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_controls_add_new_industry_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6791);
/* harmony import */ var _firebase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5268);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3392);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2494);
/* harmony import */ var _mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_controls_add_new_industry_js__WEBPACK_IMPORTED_MODULE_3__, _firebase__WEBPACK_IMPORTED_MODULE_4__, firebase_storage__WEBPACK_IMPORTED_MODULE_5__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_controls_add_new_industry_js__WEBPACK_IMPORTED_MODULE_3__, _firebase__WEBPACK_IMPORTED_MODULE_4__, firebase_storage__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
//modules imports



//api-calls





function AddnewIndustry({ isaddindustryModalvisible , setisaddindustryModalvisible , auth_role  }) {
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_6___default())();
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useToast)();
    const HandleModalOpen = ()=>{
        if (isaddindustryModalvisible !== true) {} else {
            onOpen();
            setisaddindustryModalvisible(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        HandleModalOpen();
    }, [
        isaddindustryModalvisible
    ]);
    const { 0: title , 1: set_title  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: description , 1: set_description  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: image , 1: set_image  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: image_url , 1: set_image_url  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: image_uploaded , 1: set_image_uploaded  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: is_submitting , 1: set_is_submitting  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: is_retry , 1: set_is_retry  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: pasted_image_link , 1: set_pasted_image_link  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const payload = {
        title: title,
        description: description,
        cover_image: image_url,
        auth_role
    };
    const image_file_upload_to_firebase_storage = async ()=>{
        if (image?.name == undefined) {
            toast({
                position: "top-left",
                variant: "subtle",
                title: "",
                description: "could not find image file, try re-uploading it.",
                status: "error",
                isClosable: true
            });
            return;
        } else {
            const image_documentRef = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.ref)(_firebase__WEBPACK_IMPORTED_MODULE_4__/* .storage */ .t, `industry_images/${image?.name}`);
            const snapshot = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.uploadBytes)(image_documentRef, image);
            const file_url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.getDownloadURL)(snapshot.ref);
            cookies.set("ind_image_url", file_url, {
                path: "/"
            });
            return file_url;
        }
    };
    const Upload_File = async ()=>{
        set_is_submitting(true);
        await image_file_upload_to_firebase_storage().then(()=>{
            handle_add_new_Industry();
        });
    };
    const handle_add_new_Industry = ()=>{
        if (payload.cover_image == "") {
            set_image_url(cookies.get("ind_image_url"));
            set_is_retry(true);
        } else {
            (0,_pages_api_controls_add_new_industry_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(payload).then((response)=>{
                return toast({
                    title: "",
                    description: `Successfully added ${payload.title} to industries`,
                    status: "success",
                    isClosable: true
                });
            }).then(()=>{
                cookies.remove("ind_image_url", {
                    path: "/"
                });
            }).catch((err)=>{
                console.log(err);
                toast({
                    title: "Error while adding a new Industry",
                    description: err.response.data,
                    status: "error",
                    isClosable: true
                });
            });
            set_is_retry(false);
            set_is_submitting(false);
            set_image_uploaded(false);
            onClose();
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
            isOpen: isOpen,
            onClose: onClose,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalHeader, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                children: "Add new Industry"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalCloseButton, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                spacing: 4,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                        direction: "column",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                children: "Industry"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                                type: "text",
                                                placeholder: "Industry",
                                                variant: "filled",
                                                onChange: (e)=>{
                                                    set_title(e.target.value);
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                        direction: "column",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                children: "Description"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                                type: "text",
                                                placeholder: "describe the industry",
                                                variant: "filled",
                                                onChange: (e)=>{
                                                    set_description(e.target.value);
                                                }
                                            })
                                        ]
                                    }),
                                    image_uploaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Uploaded, {
                                        name: image.name
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                        direction: "column",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                children: "Industry_image_cover"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                                type: "file",
                                                accept: ".jpeg,.jpg,.png",
                                                placeholder: "Industry_image_cover",
                                                variant: "filled",
                                                onChange: (e)=>{
                                                    set_image(e.target.files[0]);
                                                }
                                            })
                                        ]
                                    }),
                                    is_retry ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        bg: "#000",
                                        borderRadius: "0",
                                        color: "#fff",
                                        onClick: handle_add_new_Industry,
                                        children: "Finish Uploading"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        bg: "#009393",
                                        borderRadius: "0",
                                        color: "#fff",
                                        onClick: Upload_File,
                                        disabled: is_submitting ? true : false,
                                        children: "Upload Industry details"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddnewIndustry);
const Uploaded = ({ name  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
        boxShadow: "lg",
        borderRadius: "5",
        p: "2",
        borderRight: "2px solid green",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                w: "100%",
                children: [
                    name,
                    " uploaded"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_7___default()), {
                style: {
                    color: "green"
                }
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3437:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2210);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_controls_edit_industry__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5756);
/* harmony import */ var _firebase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5268);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3392);
/* harmony import */ var _mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2494);
/* harmony import */ var _mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_controls_edit_industry__WEBPACK_IMPORTED_MODULE_3__, _firebase__WEBPACK_IMPORTED_MODULE_4__, firebase_storage__WEBPACK_IMPORTED_MODULE_5__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__, _pages_api_controls_edit_industry__WEBPACK_IMPORTED_MODULE_3__, _firebase__WEBPACK_IMPORTED_MODULE_4__, firebase_storage__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function Edit_Industry_Modal({ is_edit_industry_Modalvisible , set_is_edit_industry_Modalvisible , item , auth_role  }) {
    const { isOpen , onOpen , onClose  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useToast)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_7___default())();
    //console.log(isaddingreviewgModalvisible);
    const HandleModalOpen = ()=>{
        if (is_edit_industry_Modalvisible !== true) {
        //console.log('damn')
        } else {
            onOpen();
            set_is_edit_industry_Modalvisible(false);
        }
    };
    const { 0: edited_title , 1: set_edited_title  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(item?.title);
    const { 0: edited_description , 1: set_edited_description  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(item?.description);
    const { 0: is_edit , 1: set_is_edit  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: is_change_image , 1: set_is_change_image  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: image , 1: set_image  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: image_url , 1: set_image_url  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(item?.cover_image);
    const { 0: image_uploaded , 1: set_image_uploaded  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: is_submitting , 1: set_is_submitting  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: is_retry , 1: set_is_retry  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        HandleModalOpen();
    }, [
        is_edit_industry_Modalvisible
    ]);
    const payload = {
        _id: item?._id,
        title: edited_title,
        description: edited_description,
        cover_image: image_url,
        auth_role
    };
    const handle_image_upload = async ()=>{
        if (image.name == undefined) {
            return alert("could not process image, try again.");
        } else {
            console.log(image.name);
            const image_documentRef = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.ref)(_firebase__WEBPACK_IMPORTED_MODULE_4__/* .storage */ .t, `industry_images/${image?.name}`);
            const snapshot = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.uploadBytes)(image_documentRef, image);
            set_image_uploaded(true);
            const file_url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_5__.getDownloadURL)(snapshot.ref);
            cookies.set("ind_image_url", file_url, {
                path: "/"
            });
            set_image_url(file_url);
            return file_url;
        }
    };
    //edit to new changes
    const handle_edit_Industry = async ()=>{
        set_is_submitting(true);
        //check if inputs changed; if so exit function
        if (edited_title == item?.title && edited_description == item?.description && image == "") {
            alert("No changes have been made to update industry.");
            set_is_submitting(false);
            return;
        }
        //check if image has been selected: 
        //image shows that the image file status has changed 
        // image_url stores the return url
        if (image !== "") {
            //if image file input status has changed then upload the file first then edit the industry
            await handle_image_upload().then((res)=>{
                console.log(res);
                if (res) {
                    //checks if the url has been updated to the payload
                    const payload = {
                        _id: item?._id,
                        title: edited_title,
                        description: edited_description,
                        cover_image: res,
                        auth_role
                    };
                    //Edit the technology
                    (0,_pages_api_controls_edit_industry__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(payload).then(()=>{
                        toast({
                            title: "",
                            description: `${payload.title} has been edited successfuly`,
                            status: "success",
                            isClosable: true
                        });
                    });
                    return;
                } else {
                    //fetches the url from cookies and reassigns the url to the image url
                    set_image_url(cookies.get("ind_image_url"));
                    set_is_retry(true) // this initiates the step to allow re-upload
                    ;
                    return;
                }
            });
        } else {
            //if the image status has not changed then proceed to edit the technology
            await (0,_pages_api_controls_edit_industry__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(payload).then(()=>{
                set_is_submitting(false);
                return toast({
                    title: "",
                    description: `${payload.title} has been edited successfuly`,
                    status: "success",
                    isClosable: true
                });
            }).catch((err)=>{
                toast({
                    title: "Error while editing an industry",
                    description: err.response?.data,
                    status: "error",
                    isClosable: true
                });
            });
            return;
        }
        onClose();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, {
            isOpen: isOpen,
            onClose: onClose,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalOverlay, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalContent, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalHeader, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: "32px",
                                children: "Edit Industry"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalCloseButton, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ModalBody, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                spacing: 4,
                                children: is_edit ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    gap: "2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            children: "Industry title"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                            type: "text",
                                            placeholder: edited_title,
                                            variant: "filled",
                                            onChange: (e)=>{
                                                set_edited_title(e.target.value);
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            children: "Description"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                            type: "text",
                                            placeholder: edited_description,
                                            variant: "filled",
                                            onChange: (e)=>{
                                                set_edited_description(e.target.value);
                                            }
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                            direction: "column",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                    children: "Select an image to edit cover photo"
                                                }),
                                                is_change_image || item?.cover_image == "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: image_uploaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Uploaded, {
                                                        name: image.name
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                                        type: "file",
                                                        accept: ".jpeg,.jpg,.png",
                                                        placeholder: "Industry_image_cover",
                                                        variant: "filled",
                                                        onChange: (e)=>{
                                                            set_image(e.target.files[0]);
                                                        }
                                                    })
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                    onClick: ()=>{
                                                        set_image_uploaded(false);
                                                        set_is_change_image(true);
                                                    },
                                                    children: "Change Image Photo"
                                                })
                                            ]
                                        }),
                                        is_retry ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                            bg: "#000",
                                            borderRadius: "0",
                                            color: "#fff",
                                            onClick: handle_edit_Industry,
                                            children: "Complete uploading"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                            bg: "#009393",
                                            borderRadius: "0",
                                            color: "#fff",
                                            onClick: handle_edit_Industry,
                                            disabled: is_submitting ? true : false,
                                            children: is_submitting ? "uploading..." : "Update changes"
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Image, {
                                            src: item?.cover_image,
                                            alt: "industry photo",
                                            h: "300px",
                                            w: "100%",
                                            objectFit: "cover"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "20px",
                                            fontWeight: "bold",
                                            children: item?.title
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "14px",
                                            children: item?.description
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                            bg: "#009393",
                                            borderRadius: "0",
                                            color: "#fff",
                                            onClick: ()=>{
                                                set_is_edit(true);
                                            },
                                            children: "Edit_Industry"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Edit_Industry_Modal);
const Uploaded = ({ name  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
        boxShadow: "lg",
        borderRadius: "5",
        p: "2",
        borderRight: "2px solid green",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                w: "100%",
                children: [
                    name,
                    " uploaded"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Done__WEBPACK_IMPORTED_MODULE_6___default()), {
                style: {
                    color: "green"
                }
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6791:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Add_Industry)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Add_Industry(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/add_new_industry", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/add_new_industry`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3877:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Delete_Industry)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Delete_Industry(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/delete_industry", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/delete_industry`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5756:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Edit_Industry)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Edit_Industry(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/edit_industry", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/edit_industry`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4713:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Get_Industries)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Get_Industries() {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("http://localhost:5001/api/get_industries");
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://prokemia-adminserver-production.up.railway.app/api/get_industries`);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5409:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Industry)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_modals_addNewIndustryModal_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4739);
/* harmony import */ var _components_modals_edit_industry_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3437);
/* harmony import */ var _api_controls_get_industries_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4713);
/* harmony import */ var _api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3877);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _components_modals_addNewIndustryModal_js__WEBPACK_IMPORTED_MODULE_4__, _components_modals_edit_industry_js__WEBPACK_IMPORTED_MODULE_5__, _api_controls_get_industries_js__WEBPACK_IMPORTED_MODULE_6__, _api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_7__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _components_modals_addNewIndustryModal_js__WEBPACK_IMPORTED_MODULE_4__, _components_modals_edit_industry_js__WEBPACK_IMPORTED_MODULE_5__, _api_controls_get_industries_js__WEBPACK_IMPORTED_MODULE_6__, _api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
//modules imports




//components imports


//api_calls





function Industry() {
    const { 0: isaddindustryModalvisible , 1: setisaddindustryModalvisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: is_edit_industry_Modalvisible , 1: set_is_edit_industry_Modalvisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: Industries_data , 1: set_Industries_data  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: searchquery , 1: set_searchquery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: sort , 1: set_sort  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("desc");
    const { 0: is_loading , 1: set_isloading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_8___default())();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    let token = cookies.get("admin_token");
    const { 0: auth_role , 1: set_auth_role  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        Get_Data();
        if (!token) {
            toast({
                title: "",
                description: `You need to signed in, to have access`,
                status: "info",
                isClosable: true
            });
            router.push("/");
        } else {
            let decoded = jwt_decode__WEBPACK_IMPORTED_MODULE_9___default()(token);
            set_auth_role(decoded?.role);
        }
    }, [
        token,
        sort,
        searchquery
    ]);
    const Get_Data = async ()=>{
        set_isloading(true);
        await (0,_api_controls_get_industries_js__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)().then((response)=>{
            //console.log(response.data)
            let fetched_data = response.data;
            const filtered_data = fetched_data.filter((item)=>item.verification_status && item.title?.toLowerCase().includes(searchquery.toLowerCase()));
            //console.log(filtered_data)
            if (sort == "desc") {
                const sorted_result = filtered_data.sort((a, b)=>a.title.localeCompare(b.title));
                set_Industries_data(sorted_result);
            } else {
                const sorted_result1 = filtered_data.sort((a, b)=>b.title.localeCompare(a.title));
                set_Industries_data(sorted_result1);
            }
        }).then(()=>{
            set_isloading(false);
        }).catch((err)=>{
            throw new Error("Fetching error");
            console.error(err);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        direction: "column",
        w: "100%",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_addNewIndustryModal_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                isaddindustryModalvisible: isaddindustryModalvisible,
                setisaddindustryModalvisible: setisaddindustryModalvisible,
                auth_role: auth_role
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                direction: "column",
                gap: "2",
                p: "2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        color: "#009393",
                        fontSize: "32px",
                        fontWeight: "bold",
                        children: [
                            "Industries ",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                style: {
                                    color: "#000",
                                    fontSize: "18px"
                                },
                                children: [
                                    "(",
                                    Industries_data?.length,
                                    ")"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        gap: "2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Select, {
                                placeholder: "sort",
                                w: "100px",
                                onChange: (e)=>{
                                    set_sort(e.target.value);
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                        value: "desc",
                                        children: "A - Z"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                        value: "asc",
                                        children: "Z - A"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                placeholder: "search industry",
                                onChange: (e)=>{
                                    set_searchquery(e.target.value);
                                }
                            })
                        ]
                    }),
                    is_loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item_Loading, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item_Loading, {})
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        gap: "2",
                        direction: "column",
                        h: "80vh",
                        overflowY: "scroll",
                        children: Industries_data?.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Industry_Item, {
                                item: item,
                                auth_role: auth_role
                            }, item._id);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Circle, {
                        _hover: {
                            transform: "scale(1.03)",
                            transition: "ease-out 0.9s all"
                        },
                        onClick: ()=>{
                            setisaddindustryModalvisible(true);
                        },
                        boxShadow: "dark-lg",
                        cursor: "pointer",
                        color: "#fff",
                        boxSize: "60px",
                        bg: "#009393",
                        position: "fixed",
                        bottom: "20px",
                        right: "20px",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_10___default()), {})
                    })
                ]
            })
        ]
    });
}
const Industry_Item = ({ item , auth_role  })=>{
    const toast1 = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_8___default())();
    const { 0: is_edit_industry_Modalvisible , 1: set_is_edit_industry_Modalvisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const payload = {
        _id: item._id,
        auth_role
    };
    const handle_delete_industry = async ()=>{
        let response = prompt(`Are you sure you want to delete this industry? Enter, the title of the industry: ${item.title} to confirm.`);
        if (response === item.title) {
            await (0,_api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(payload).then(()=>{
                toast1({
                    title: "",
                    description: `${item?.title} has been deleted`,
                    status: "info",
                    isClosable: true
                });
            }).then(()=>{
                cookies.remove("ind_image_url", {
                    path: "/"
                });
            }).catch((err)=>{
                console.log(err);
                toast1({
                    title: "error while deleting this industry",
                    description: err.response?.data,
                    status: "error",
                    isClosable: true
                });
            });
        } else {
            toast1({
                title: `Deletion for ${item?.title} has been cancelled.`,
                description: `Input titles do not match`,
                status: "info",
                isClosable: true
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        borderRadius: "5",
        bg: "#fff",
        gap: "1",
        boxShadow: "lg",
        justify: "space-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Image, {
                src: item.cover_image,
                alt: "industry photo",
                boxSize: "100px",
                objectFit: "cover",
                borderRadius: "5"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                direction: "column",
                flex: "1",
                p: "2",
                gap: "2",
                h: "100px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontWeight: "bold",
                        color: "#009393",
                        children: item?.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        h: "60%",
                        overflow: "hidden",
                        children: item?.description
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                justify: "space-between",
                direction: "column",
                p: "2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        p: "1",
                        borderRadius: "5px",
                        border: "1px solid #000",
                        onClick: ()=>{
                            set_is_edit_industry_Modalvisible(true);
                        },
                        cursor: "pointer",
                        children: "Edit"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        p: "1",
                        borderRadius: "5px",
                        color: "red",
                        border: "1px solid red",
                        cursor: "pointer",
                        onClick: handle_delete_industry,
                        children: "Delete"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modals_edit_industry_js__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                is_edit_industry_Modalvisible: is_edit_industry_Modalvisible,
                set_is_edit_industry_Modalvisible: set_is_edit_industry_Modalvisible,
                item: item,
                auth_role: auth_role
            })
        ]
    });
};
const Item_Loading = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        bg: "#fff",
        direction: "column",
        borderRadius: "5px",
        boxShadow: "lg",
        justify: "space-between",
        position: "relative",
        p: "2",
        gap: "2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                bg: "#eee",
                w: "80%",
                h: "25px",
                borderRadius: "5px"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        bg: "#eee",
                        w: "50px",
                        h: "25px",
                        borderRadius: "5px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        bg: "#eee",
                        w: "120px",
                        h: "25px",
                        borderRadius: "5px"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        bg: "#eee",
                        w: "50px",
                        h: "25px",
                        borderRadius: "5px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        bg: "#eee",
                        w: "120px",
                        h: "25px",
                        borderRadius: "5px"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                bg: "#eee",
                position: "absolute",
                top: "10px",
                right: "15px",
                w: "25px",
                h: "25px",
                borderRadius: "5px"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        bg: "#eee",
                        w: "120px",
                        h: "35px",
                        borderRadius: "5px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        bg: "#eee",
                        w: "120px",
                        h: "35px",
                        borderRadius: "5px"
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;