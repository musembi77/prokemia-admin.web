exports.id = 7673;
exports.ids = [7673];
exports.modules = {

/***/ 168:
/***/ ((module) => {

// Exports
module.exports = {
	"Menu_Bar_Body": "Header_Menu_Bar_Body__cS1mm",
	"Menu_items_container": "Header_Menu_items_container__XoBxi"
};


/***/ }),

/***/ 7673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_Header_module_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(168);
/* harmony import */ var _styles_Header_module_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_styles_Header_module_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_NotificationsActive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1383);
/* harmony import */ var _mui_icons_material_NotificationsActive__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_NotificationsActive__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _pages_api_auth_get_admin_user_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4262);
/* harmony import */ var _pages_api_auth_edit_admin_user_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2936);
/* harmony import */ var _mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1883);
/* harmony import */ var _mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_ManageAccounts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8281);
/* harmony import */ var _mui_icons_material_ManageAccounts__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ManageAccounts__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4845);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9881);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_HorizontalRule__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1648);
/* harmony import */ var _mui_icons_material_HorizontalRule__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HorizontalRule__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9233);
/* harmony import */ var _mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _pages_api_auth_get_admin_user_js__WEBPACK_IMPORTED_MODULE_8__, _pages_api_auth_edit_admin_user_js__WEBPACK_IMPORTED_MODULE_9__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _pages_api_auth_get_admin_user_js__WEBPACK_IMPORTED_MODULE_8__, _pages_api_auth_edit_admin_user_js__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















function Header() {
    const { 0: showmenubar , 1: setshowmenubar  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_5___default())();
    let token = cookies.get("admin_token");
    const { 0: user_data , 1: set_user_data  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!token) {
            toast({
                title: "",
                description: `You need to signed in, to have access`,
                status: "info",
                isClosable: true
            });
            router.push("/");
            return;
        } else {
            let decoded = jwt_decode__WEBPACK_IMPORTED_MODULE_7___default()(token);
            //console.log(decoded);
            let id = decoded?.id;
            fetch_user_details(id);
        }
    }, []);
    const handle_LogOut = async ()=>{
        const payload = {
            _id: user_data?._id,
            login_status: false
        };
        await (0,_pages_api_auth_edit_admin_user_js__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(payload).then(()=>{
            cookies.remove("admin_token", {
                path: "/"
            });
            toast({
                title: "successfully logged out",
                description: ``,
                status: "success",
                isClosable: true
            });
        }).then(()=>{
            router.push("/");
        }).catch((err)=>{
            toast({
                title: "error while logging out",
                description: ``,
                status: "error",
                isClosable: true
            });
            console.log(err);
        });
    };
    const fetch_user_details = async (id)=>{
        ////console.log(id)
        const payload = {
            _id: id
        };
        //console.log(payload)
        await (0,_pages_api_auth_get_admin_user_js__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(payload).then((res)=>{
            //console.log(res.data)
            if (res.data?.login_status) {
                set_user_data(res.data);
            } else {
                router.push("/");
                cookies.remove("admin_token", {
                    path: "/"
                });
                toast({
                    title: "You have been signed out.",
                    description: `For any issues contact support or the administrator.`,
                    status: "success",
                    isClosable: true
                });
                return;
            }
        }).catch((err)=>{
            if (err.response?.status == 500) {
                toast({
                    title: "You have been signed out.",
                    description: `You do not have access to this platform.`,
                    status: "success",
                    isClosable: true
                });
                router.push("/");
                return;
            }
            console.log(err);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        cursor: "pointer",
        bg: "#fff",
        fontFamily: "ClearSans-Bold",
        h: "70px",
        p: "2",
        justify: "space-between",
        align: "center",
        position: "sticky",
        top: "0px",
        zIndex: "10",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                p: "2",
                align: "center",
                gap: "1",
                borderRadius: "5",
                color: "#fff",
                onClick: ()=>{
                    router.push(`/profile/${user_data?._id}`);
                },
                children: user_data?.user_image == "" || !user_data?.user_image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_10___default()), {
                    style: {
                        color: "grey",
                        fontSize: "35px"
                    }
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Image, {
                    src: user_data?.user_image,
                    boxSize: "35px",
                    boxShadow: "lg",
                    borderRadius: "40px",
                    alt: "pp"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                align: "center",
                gap: "3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        w: "120%",
                        p: "3",
                        fontSize: "14px",
                        bg: "#009393",
                        color: "#fff",
                        onClick: ()=>{
                            router.push(`/product/add_product`);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Add, {
                                style: {
                                    fontSize: "18px"
                                }
                            }),
                            "Add Product"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        w: "100%",
                        bg: "#000",
                        color: "#fff",
                        onClick: handle_LogOut,
                        children: "Log-out"
                    }),
                    showmenubar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Close, {
                        onClick: ()=>{
                            setshowmenubar(!showmenubar);
                        }
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Menu, {
                        onClick: ()=>{
                            setshowmenubar(!showmenubar);
                        }
                    }),
                    showmenubar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuBar, {
                        setshowmenubar: setshowmenubar,
                        showmenubar: showmenubar,
                        user_data: user_data
                    }) : null
                ]
            })
        ]
    });
}
const navigation = [
    {
        id: 1,
        title: "Inventory",
        link: "inventory",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Inventory, {})
    },
    {
        id: 2,
        title: "Orders",
        link: "orders",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Receipt, {})
    },
    {
        id: 3,
        title: "Distributors",
        link: "distributors",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Groups, {})
    },
    {
        id: 4,
        title: "Salespersons",
        link: "salespersons",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Groups, {})
    },
    {
        id: 5,
        title: "Manufacturers",
        link: "manufacturers",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Groups, {})
    },
    {
        id: 6,
        title: "Customers",
        link: "customers",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Groups, {})
    },
    {
        id: 7,
        title: "Control",
        link: "util_controls",
        logo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Tune, {})
    }, 
];
const MenuBar = ({ setshowmenubar , showmenubar , user_data  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { 0: handle_persmission_sub_menu , 1: set_handle_persmission_sub_menu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        className: (_styles_Header_module_css__WEBPACK_IMPORTED_MODULE_16___default().Menu_Bar_Body),
        gap: "2",
        p: "4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        flex: "1",
                        align: "center",
                        p: "2",
                        bg: "#fff",
                        borderRadius: "5",
                        onClick: ()=>{
                            router.push("/dashboard");
                            setshowmenubar(!showmenubar);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_3__.Widgets, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "14px",
                                mb: "0",
                                children: "Dashboard"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        flex: "1",
                        align: "center",
                        p: "2",
                        bg: "#fff",
                        borderRadius: "5",
                        onClick: ()=>{
                            router.push("/notifications");
                            setshowmenubar(!showmenubar);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_NotificationsActive__WEBPACK_IMPORTED_MODULE_6___default()), {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "14px",
                                mb: "0",
                                children: "Notifications"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                className: (_styles_Header_module_css__WEBPACK_IMPORTED_MODULE_16___default().Menu_items_container),
                direction: "column",
                h: "90%",
                overflowY: "scroll",
                w: "100%",
                p: "2",
                children: [
                    navigation.map((item)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                            borderBottom: "1px solid grey",
                            p: "2",
                            _hover: {
                                transition: "ease-out 0.9s all",
                                backgroundColor: "#fff",
                                color: "#000",
                                borderRadius: "5"
                            },
                            align: "center",
                            color: "#fff",
                            onClick: ()=>{
                                router.push(`/${item.link}`);
                                setshowmenubar(!showmenubar);
                            },
                            children: [
                                item.logo,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    p: "2",
                                    fontSize: "20px",
                                    mb: "0",
                                    children: item.title
                                })
                            ]
                        }, item?.id);
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        borderBottom: "1px solid grey",
                        p: "2",
                        _hover: {
                            transition: "ease-out 0.9s all",
                            backgroundColor: "#fff",
                            color: "#000",
                            borderRadius: "5"
                        },
                        align: "center",
                        color: "#fff",
                        onClick: ()=>{
                            router.push(`/profile/${user_data?._id}`);
                            setshowmenubar(!showmenubar);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AccountCircle__WEBPACK_IMPORTED_MODULE_10___default()), {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                p: "2",
                                fontSize: "20px",
                                mb: "0",
                                children: "Profile"
                            })
                        ]
                    }),
                    user_data?.role === "Manager" || user_data?.role === "IT" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                justify: "space-between",
                                borderBottom: "1px solid grey",
                                p: "2",
                                _hover: {
                                    transition: "ease-out 0.9s all",
                                    backgroundColor: "#fff",
                                    color: "#000",
                                    borderRadius: "5"
                                },
                                align: "center",
                                color: "#fff",
                                onClick: ()=>{
                                    set_handle_persmission_sub_menu(!handle_persmission_sub_menu);
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                        align: "center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ManageAccounts__WEBPACK_IMPORTED_MODULE_11___default()), {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                p: "2",
                                                fontSize: "20px",
                                                mb: "0",
                                                children: "Permissions&Accounts"
                                            })
                                        ]
                                    }),
                                    handle_persmission_sub_menu ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_13___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_12___default()), {})
                                ]
                            }),
                            handle_persmission_sub_menu ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Permission_accounts_controllers, {
                                setshowmenubar: setshowmenubar,
                                showmenubar: showmenubar
                            }) : null
                        ]
                    }) : null
                ]
            })
        ]
    });
};
const Permission_accounts_controllers = ({ setshowmenubar , showmenubar  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        direction: "column",
        ml: "5%",
        color: "#fff",
        gap: "2",
        mt: "2",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                align: "center",
                gap: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_15___default()), {
                        style: {
                            fontSize: "10px"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        p: "2",
                        fontSize: "",
                        mb: "0",
                        onClick: ()=>{
                            router.push(`/Permissions&Accounts/User_Management`);
                            setshowmenubar(!showmenubar);
                        },
                        children: "User Management"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Divider, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                align: "center",
                gap: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Circle__WEBPACK_IMPORTED_MODULE_15___default()), {
                        style: {
                            fontSize: "10px"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        p: "2",
                        fontSize: "",
                        mb: "0",
                        onClick: ()=>{
                            router.push(`/Permissions&Accounts/Role_Management`);
                            setshowmenubar(!showmenubar);
                        },
                        children: "Role Management"
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2936:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Edit_Admin_User)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Edit_Admin_User(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/edit_admin_user", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/edit_admin_user`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4262:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Get_Admin_User)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Get_Admin_User(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/get_admin_user", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/get_admin_user`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;