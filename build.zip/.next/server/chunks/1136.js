"use strict";
exports.id = 1136;
exports.ids = [1136];
exports.modules = {

/***/ 1136:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Upload_Edited_Files_Test)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_Products_edit_product_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6807);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_firebase_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5268);
/* harmony import */ var firebase_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3392);
/* harmony import */ var _components_Loading_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _api_Products_edit_product_js__WEBPACK_IMPORTED_MODULE_4__, _components_firebase_js__WEBPACK_IMPORTED_MODULE_7__, firebase_storage__WEBPACK_IMPORTED_MODULE_8__, _components_Loading_js__WEBPACK_IMPORTED_MODULE_9__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _api_Products_edit_product_js__WEBPACK_IMPORTED_MODULE_4__, _components_firebase_js__WEBPACK_IMPORTED_MODULE_7__, firebase_storage__WEBPACK_IMPORTED_MODULE_8__, _components_Loading_js__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
//modules imports




//api calls 

//icons imports

//utils 



//import { v4 } from "uuid";
//components

function Upload_Edited_Files_Test({ set_iseditfiles , product_data , auth_role  }) {
    /**
     * Upload_Edited_Files_Test: Handles the upload and update of files.
     * Files: data sheet, safety data sheet, formulation document
     * Props:
     *      set_isfileupload (Boolean): handles the state of visibility of file upload.
     * 
     */ //utils
    const toast = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_6___default())();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    //Existing file
    const { 0: is_data_sheet_existing , 1: set_is_data_sheet_existing  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product_data?.data_sheet);
    const { 0: is_safety_data_sheet_existing , 1: set_is_safety_data_sheet_existing  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product_data?.safety_data_sheet);
    const { 0: is_formulation_document_existing , 1: set_is_formulation_document_existing  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product_data?.formulation_document);
    //Change file
    const { 0: is_change_data_sheet , 1: set_is_change_data_sheet  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: is_change_safety_data_sheet , 1: set_is_change_safety_data_sheet  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: is_change_formulation_document , 1: set_is_change_formulation_document  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    //upload status of each file
    const { 0: is_data_sheet_uploaded , 1: set_is_data_sheet_uploaded  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: is_safety_data_sheet_uploaded , 1: set_is_safety_data_sheet_uploaded  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: is_formulation_document_uploaded , 1: set_is_formulation_document_uploaded  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    //input data state handlers
    const { 0: data_sheet , 1: set_data_sheet  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""); //handles the state of data sheet file selection
    const { 0: safety_data_sheet , 1: set_safety_data_sheet  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""); //handles the state of safety data sheet file selection
    const { 0: formulation_document , 1: set_formulation_document  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""); //handles the state of formulation document file selection
    //url file state handlers
    const { 0: data_sheet_url , 1: set_data_sheet_url  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""); //handles the state of data sheet file selection
    const { 0: safety_data_sheet_url , 1: set_safety_data_sheet_url  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""); //handles the state of safety data sheet file selection
    const { 0: formulation_document_url , 1: set_formulation_document_url  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""); //handles the state of formulation document file selection
    //loading Status
    const { 0: is_submitting , 1: set_is_submitting  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const files = {
        data_sheet_url,
        safety_data_sheet_url,
        formulation_document_url
    };
    const data_sheet_file_upload_to_firebase_storage = async ()=>{
        if (data_sheet?.name == undefined) {
            toast({
                position: "top-left",
                variant: "subtle",
                title: "",
                description: "could not find data sheet file, try re-uploading it.",
                status: "error",
                isClosable: true
            });
            return;
        } else {
            const data_sheet_documentRef = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.ref)(_components_firebase_js__WEBPACK_IMPORTED_MODULE_7__/* .storage */ .t, `data_sheet/${data_sheet?.name}`);
            const snapshot = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.uploadBytes)(data_sheet_documentRef, data_sheet);
            const file_url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.getDownloadURL)(snapshot.ref);
            cookies.set("data_sheet_url", file_url, {
                path: "/"
            });
            return file_url;
        }
    };
    const safety_data_sheet_file_upload_to_firebase_storage = async ()=>{
        if (safety_data_sheet?.name == undefined) {
            toast({
                position: "top-left",
                variant: "subtle",
                title: "",
                description: "could not find safety data sheet file, try re-uploading it.",
                status: "error",
                isClosable: true
            });
            return;
        } else {
            const safety_data_sheet_documentRef = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.ref)(_components_firebase_js__WEBPACK_IMPORTED_MODULE_7__/* .storage */ .t, `safety_data_sheet/${safety_data_sheet?.name}`);
            const snapshot = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.uploadBytes)(safety_data_sheet_documentRef, safety_data_sheet);
            const file_url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.getDownloadURL)(snapshot.ref);
            cookies.set("safety_data_sheet_url", file_url, {
                path: "/"
            });
            return file_url;
        }
    };
    const formulation_document_file_upload_to_firebase_storage = async ()=>{
        if (formulation_document?.name == undefined) {
            toast({
                position: "top-left",
                variant: "subtle",
                title: "",
                description: "could not find formulation document file, try re-uploading it.",
                status: "error",
                isClosable: true
            });
            return;
        } else {
            const formulation_document_documentRef = (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.ref)(_components_firebase_js__WEBPACK_IMPORTED_MODULE_7__/* .storage */ .t, `formulation_document/${formulation_document?.name}`);
            const snapshot = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.uploadBytes)(formulation_document_documentRef, formulation_document);
            const file_url = await (0,firebase_storage__WEBPACK_IMPORTED_MODULE_8__.getDownloadURL)(snapshot.ref);
            ;
            cookies.set("formulation_document_url", file_url, {
                path: "/"
            });
            return file_url;
        }
    };
    // handles uploaded urls
    const fetch_file_urls = async ()=>{
        if (data_sheet) {
            let get_data_sheet_file_url = await data_sheet_file_upload_to_firebase_storage();
            console.log(get_data_sheet_file_url);
            set_data_sheet_url(get_data_sheet_file_url);
            files.data_sheet_url = get_data_sheet_file_url;
        } else {
            files.data_sheet_url = product_data?.data_sheet;
        }
        if (safety_data_sheet) {
            let get_safety_data_sheet_file_url = await safety_data_sheet_file_upload_to_firebase_storage();
            console.log(get_safety_data_sheet_file_url);
            set_safety_data_sheet_url(get_safety_data_sheet_file_url);
            files.safety_data_sheet_url = get_safety_data_sheet_file_url;
        } else {
            files.safety_data_sheet_url = product_data?.safety_data_sheet;
        }
        if (formulation_document) {
            let get_formulation_document_file_url = await formulation_document_file_upload_to_firebase_storage();
            console.log(get_formulation_document_file_url);
            set_formulation_document_url(get_formulation_document_file_url);
            files.formulation_document_url = get_formulation_document_file_url;
        } else {
            files.formulation_document_url = product_data?.formulation_document;
        }
    };
    const Handle_Upload_Documents = async ()=>{
        /**
         * Handles the process of uploading the documents to the product in db.
         * Control the uploading of individual files.
         */ set_is_submitting(true);
        let file_checker = File_Type_Checker();
        if (file_checker) {
            set_is_submitting(false);
            return;
        }
        if (!data_sheet || !safety_data_sheet || !formulation_document) {
            /**
             * Checks the existence of all files and asks if the user wishes to upload only the uploaded documents
             * if so the files are uploaded and the product is edited
             * elsewise the user goes to edit the files.
             * 
            */ let confirmation = prompt("Are you sure you want to edit only the files you have changed? Confirm by typing [ yes ] below.");
            if (confirmation === "yes") {
                //Edit product
                fetch_file_urls().then(()=>{
                    Update_Product_Details();
                }).catch((err)=>{
                    console.log(err);
                    set_is_submitting(false);
                });
            } else {
                set_is_submitting(false);
                return;
            }
        } else {
            //Create product
            fetch_file_urls().then(()=>{
                Update_Product_Details();
            }).catch((err)=>{
                console.log(err);
                set_is_submitting(false);
            });
        }
    };
    const Update_Product_Details = async ()=>{
        let payload = {
            data_sheet_url: files?.data_sheet_url,
            safety_data_sheet_url: files?.safety_data_sheet_url,
            formulation_document_url: files?.formulation_document_url,
            _id: product_data?._id,
            auth_role: auth_role
        };
        console.log(payload);
        await (0,_api_Products_edit_product_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(payload).then(()=>{
            /**
				sends a payload data to server to update the product.
				payload (object): json obj containing information for the product.

				Return:
					alerts user whether function runs successfully or not.
				catch:
					alerts user when function fails
			*/ toast({
                title: "",
                position: "top-left",
                variant: "subtle",
                description: `file(s) have been edited successfully`,
                status: "success",
                isClosable: true
            });
            set_is_data_sheet_uploaded(true);
            set_is_safety_data_sheet_uploaded(true);
            set_is_formulation_document_uploaded(true);
            setTimeout(()=>{
                set_iseditfiles(false);
                router.back();
                Clean_input_data();
            }, 2000);
        }).catch((err)=>{
            console.log(err);
            toast({
                position: "top-left",
                variant: "subtle",
                title: "Error while uploading files",
                description: "your files could not be edited, contact support",
                status: "error",
                isClosable: true
            });
        }).finally(()=>{
            set_is_submitting(false);
        });
    };
    const File_Type_Checker = ()=>{
        /**
         * File_Type_Checker: Checks if the uploaded files are of pdf format.
         * Returns:
         *      true if any files are not of the correct format
         *      false if the files are of the right format.
        */ const check_data_sheet = ()=>{
            if (data_sheet.type !== "application/pdf" && data_sheet) {
                toast({
                    position: "top-left",
                    variant: "subtle",
                    title: "Data sheet file:wrong file type selected",
                    description: "only pdf files are allowed",
                    status: "info",
                    isClosable: true
                });
                return true;
            } else {
                return false;
            }
        };
        const check_safety_data_sheet = ()=>{
            if (safety_data_sheet.type !== "application/pdf" && safety_data_sheet) {
                toast({
                    position: "top-left",
                    variant: "subtle",
                    title: "Safety Data sheet file:wrong file type selected",
                    description: "only pdf files are allowed",
                    status: "info",
                    isClosable: true
                });
                return true;
            } else {
                return false;
            }
        };
        const check_formulation_document = ()=>{
            if (formulation_document.type !== "application/pdf" && formulation_document) {
                toast({
                    position: "top-left",
                    variant: "subtle",
                    title: "Formulation document: wrong file type selected",
                    description: "only pdf files are allowed",
                    status: "info",
                    isClosable: true
                });
                return true;
            } else {
                return false;
            }
        };
        let data_sheet_checker = check_data_sheet();
        let safety_data_sheet_checker = check_safety_data_sheet();
        let formulation_document_checker = check_formulation_document();
        if (data_sheet_checker || safety_data_sheet_checker || formulation_document_checker) {
            return true;
        } else {
            return false;
        }
    };
    const Clean_input_data = ()=>{
        //clear file urls
        set_data_sheet_url("");
        set_safety_data_sheet_url("");
        set_formulation_document_url("");
        //clear file data
        set_data_sheet("");
        set_safety_data_sheet("");
        set_formulation_document("");
        //clear file selection status
        set_is_data_sheet_uploaded(false);
        set_is_safety_data_sheet_uploaded(false);
        set_is_formulation_document_uploaded(false);
        //clear file is changing status
        set_is_change_data_sheet(false);
        set_is_change_safety_data_sheet(false);
        set_is_change_formulation_document(false);
        //clear file existing status
        set_is_data_sheet_existing(false);
        set_is_safety_data_sheet_existing(false);
        set_is_formulation_document_existing(false);
        //clear files obj
        files.data_sheet_url = "";
        files.safety_data_sheet_url = "";
        files.formulation_document_url = "";
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        direction: "column",
        w: "90vw",
        boxShadow: "lg",
        p: "2",
        gap: "2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                color: "#009393",
                fontSize: "24px",
                fontWeight: "bold",
                m: "2",
                children: "Edit Documents"
            }),
            is_data_sheet_uploaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Uploaded_Card_Item, {
                name: data_sheet?.name
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: is_change_data_sheet ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: data_sheet ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        p: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontWeight: "bold",
                                children: "Data Sheet"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Selected_Card_Item, {
                                is_submitting: is_submitting,
                                name: data_sheet?.name,
                                file_type: "data_sheet",
                                set_data_sheet: set_data_sheet
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        p: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: "Data Sheet"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                align: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                        type: "file",
                                        placeholder: "product data sheet",
                                        variant: "filled",
                                        onChange: (e)=>{
                                            set_data_sheet(e.target.files[0]);
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Close, {
                                        onClick: ()=>{
                                            set_is_change_data_sheet(false);
                                        }
                                    })
                                ]
                            })
                        ]
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: is_data_sheet_existing === "" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        h: "10vh",
                        align: "center",
                        p: "2",
                        justify: "space-between",
                        gap: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bg: "#eee",
                                p: "2",
                                borderRadius: "5",
                                flex: "1",
                                children: "No data sheet file has been uploaded"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.PostAdd, {
                                onClick: ()=>{
                                    set_is_change_data_sheet(true);
                                },
                                style: {
                                    cursor: "pointer"
                                }
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Existing_files_Card_Item, {
                        name: "Data sheet document",
                        link: product_data?.data_sheet,
                        set_is_change_data_sheet: set_is_change_data_sheet
                    })
                })
            }),
            is_safety_data_sheet_uploaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Uploaded_Card_Item, {
                name: safety_data_sheet?.name
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: is_change_safety_data_sheet ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: safety_data_sheet ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        p: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontWeight: "bold",
                                children: "Safety Data Sheet"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Selected_Card_Item, {
                                is_submitting: is_submitting,
                                name: safety_data_sheet?.name,
                                file_type: "safety_data_sheet",
                                set_safety_data_sheet: set_safety_data_sheet
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        p: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: "Safety Data Sheet"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                align: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                        type: "file",
                                        placeholder: "product safety data sheet",
                                        variant: "filled",
                                        onChange: (e)=>{
                                            set_safety_data_sheet(e.target.files[0]);
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Close, {
                                        onClick: ()=>{
                                            set_is_change_safety_data_sheet(false);
                                        }
                                    })
                                ]
                            })
                        ]
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: is_safety_data_sheet_existing === "" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        h: "10vh",
                        align: "center",
                        p: "2",
                        justify: "space-between",
                        gap: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bg: "#eee",
                                p: "2",
                                borderRadius: "5",
                                flex: "1",
                                children: "No safety data sheet file has been uploaded"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.PostAdd, {
                                onClick: ()=>{
                                    set_is_change_safety_data_sheet(true);
                                },
                                style: {
                                    cursor: "pointer"
                                }
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Existing_files_Card_Item, {
                        name: "Safety Data sheet document",
                        link: product_data?.safety_data_sheet,
                        set_is_change_safety_data_sheet: set_is_change_safety_data_sheet
                    })
                })
            }),
            is_formulation_document_uploaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Uploaded_Card_Item, {
                name: formulation_document?.name
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: is_change_formulation_document ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: formulation_document ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        p: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontWeight: "bold",
                                children: "formulation_document"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Selected_Card_Item, {
                                is_submitting: is_submitting,
                                name: formulation_document?.name,
                                file_type: "formulation_document",
                                set_formulation_document: set_formulation_document
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        direction: "column",
                        p: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontWeight: "bold",
                                children: "Formulation_document"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                align: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                        type: "file",
                                        placeholder: "Formulation Dcument",
                                        variant: "filled",
                                        onChange: (e)=>{
                                            set_formulation_document(e.target.files[0]);
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Close, {
                                        onClick: ()=>{
                                            set_is_change_formulation_document(false);
                                        }
                                    })
                                ]
                            })
                        ]
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: is_formulation_document_existing === "" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        h: "10vh",
                        align: "center",
                        p: "2",
                        justify: "space-between",
                        gap: "2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                bg: "#eee",
                                p: "2",
                                borderRadius: "5",
                                flex: "1",
                                children: "No formulation document file has been uploaded"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.PostAdd, {
                                onClick: ()=>{
                                    set_is_change_formulation_document(true);
                                },
                                style: {
                                    cursor: "pointer"
                                }
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Existing_files_Card_Item, {
                        name: "Formulation document",
                        link: product_data?.formulation_document,
                        set_is_change_formulation_document: set_is_change_formulation_document
                    })
                })
            }),
            is_submitting ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                bg: "#009393",
                borderRadius: "0",
                flex: "1",
                color: "#fff",
                align: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading_js__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        width: "40px",
                        height: "40px",
                        color: "#ffffff"
                    }),
                    "saving product..."
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                m: "2",
                gap: "2",
                color: "#fff",
                children: [
                    data_sheet || safety_data_sheet || formulation_document ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        flex: "1",
                        bg: "#000",
                        onClick: Handle_Upload_Documents,
                        children: "Upload files"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        flex: "1",
                        bg: "#000",
                        children: "Edit files"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        flex: "1",
                        m: "2",
                        mt: "0",
                        h: "40px",
                        border: "1px solid #000",
                        color: "#000",
                        onClick: ()=>{
                            set_iseditfiles(false);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.ArrowBack, {
                                style: {
                                    marginTop: "5px"
                                }
                            }),
                            "Go back "
                        ]
                    })
                ]
            })
        ]
    });
}
const Existing_files_Card_Item = ({ name , set_is_change_data_sheet , set_is_change_safety_data_sheet , set_is_change_formulation_document  })=>{
    const handle_file_change = ()=>{
        switch(name){
            case "Data sheet document":
                set_is_change_data_sheet(true);
                break;
            case "Safety Data sheet document":
                set_is_change_safety_data_sheet(true);
                break;
            case "Formulation document":
                set_is_change_formulation_document(true);
                break;
            default:
                return;
        }
    //<Link href={link} isExternal border='1px solid grey' p='2' borderRadius='5'>View</Link>
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        justify: "space-between",
        boxShadow: "lg",
        p: "2",
        align: "center",
        borderRadius: "5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                fontWeight: "bold",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.InsertDriveFile, {
                        style: {
                            color: "#009393"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        children: name
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                align: "center",
                gap: "3",
                mr: "1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.DriveFileRenameOutline, {
                        onClick: handle_file_change,
                        style: {
                            cursor: "pointer"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.DeleteOutline, {
                        onClick: handle_file_change,
                        style: {
                            color: "red",
                            cursor: "pointer",
                            borderLeft: "1px solid grey"
                        }
                    })
                ]
            })
        ]
    });
};
const Selected_Card_Item = ({ name , file_type , set_data_sheet , set_safety_data_sheet , set_formulation_document , is_submitting  })=>{
    const handle_remove_file = ()=>{
        switch(file_type){
            case "data_sheet":
                set_data_sheet("");
                break;
            case "safety_data_sheet":
                set_safety_data_sheet("");
                break;
            case "formulation_document":
                set_formulation_document("");
                break;
            default:
                return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        boxShadow: "lg",
        borderRadius: "5",
        p: "2",
        borderRight: "2px solid orange",
        justify: "space-between",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Description, {
                        style: {
                            color: "orange"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        w: "100%",
                        children: name
                    })
                ]
            }),
            is_submitting ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Close, {
                style: {
                    color: "grey",
                    cursor: "pointer"
                }
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Close, {
                style: {
                    color: "#000",
                    cursor: "pointer"
                },
                onClick: handle_remove_file
            })
        ]
    });
};
const Uploaded_Card_Item = ({ name  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        boxShadow: "lg",
        borderRadius: "5",
        p: "2",
        borderRight: "2px solid green",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                w: "100%",
                children: [
                    name,
                    " uploaded"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_5__.Done, {
                style: {
                    color: "green"
                }
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;