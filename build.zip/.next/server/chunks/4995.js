"use strict";
exports.id = 4995;
exports.ids = [4995];
exports.modules = {

/***/ 7085:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Approve_Industry)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Approve_Industry(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/approve_suggested_industry", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/approve_suggested_industry`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3877:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Delete_Industry)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Delete_Industry(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/delete_industry", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/delete_industry`, payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4713:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Get_Industries)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Get_Industries() {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("http://localhost:5001/api/get_industries");
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://prokemia-adminserver-production.up.railway.app/api/get_industries`);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Industries)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2210);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_controls_get_industries__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4713);
/* harmony import */ var _api_controls_approve_industry__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7085);
/* harmony import */ var _api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3877);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _api_controls_get_industries__WEBPACK_IMPORTED_MODULE_4__, _api_controls_approve_industry__WEBPACK_IMPORTED_MODULE_5__, _api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_6__]);
([_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__, _api_controls_get_industries__WEBPACK_IMPORTED_MODULE_4__, _api_controls_approve_industry__WEBPACK_IMPORTED_MODULE_5__, _api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function Industries() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_7___default())();
    let token = cookies.get("admin_token");
    const { 0: auth_role , 1: set_auth_role  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: industries_data , 1: set_industries_data  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const get_Industries_Data = async ()=>{
        await (0,_api_controls_get_industries__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)().then((response)=>{
            //console.log(response.data)
            const data = response.data;
            const result = data.filter((v)=>!v.verification_status);
            //console.log(data.filter(v => !v.verification_status))
            set_industries_data(result);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        get_Industries_Data();
        if (!token) {
            toast({
                title: "",
                description: `You need to signed in, to have access`,
                status: "info",
                isClosable: true
            });
            router.push("/");
        } else {
            let decoded = jwt_decode__WEBPACK_IMPORTED_MODULE_8___default()(token);
            //console.log(decoded);
            set_auth_role(decoded?.role);
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        direction: "column",
        gap: "3",
        p: "2",
        w: "100%",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontSize: "32px",
                fontWeight: "bold",
                color: "#009393",
                children: "Industries"
            }),
            industries_data?.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justify: "center",
                align: "center",
                h: "40vh",
                direction: "column",
                gap: "2",
                textAlign: "center",
                bg: "#eee",
                borderRadius: "5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    children: "You dont have new industries to verify."
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                direction: "column",
                overflowY: "scroll",
                h: "80vh",
                children: industries_data?.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Industry, {
                        item: item,
                        auth_role: auth_role
                    }, item._id);
                })
            })
        ]
    });
}
const Industry = ({ item , auth_role  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const toast1 = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.useToast)();
    const payload = {
        _id: item?._id,
        auth_role
    };
    const handle_approve_industry = async ()=>{
        await (0,_api_controls_approve_industry__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(payload).then(()=>{
            toast1({
                title: "",
                description: `${item?.title} has been approved`,
                status: "info",
                isClosable: true
            });
        }).catch((err)=>{
            toast1({
                title: "could not approve this industry",
                description: err.response?.data,
                status: "error",
                isClosable: true
            });
        });
    };
    const handle_delete_industry = async ()=>{
        await (0,_api_controls_delete_industry_js__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(payload).then(()=>{
            toast1({
                title: "",
                description: `${item?.title} has been deleted`,
                status: "info",
                isClosable: true
            });
        }).catch((err)=>{
            //console.log(err)
            toast1({
                title: "could not delete this industry",
                description: err.response?.data,
                status: "error",
                isClosable: true
            });
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
        direction: "column",
        bg: "#eee",
        boxShadow: "lg",
        borderRadius: "5",
        m: "2",
        p: "2",
        gap: "2",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                fontWeight: "bold",
                fontSize: "20px",
                children: [
                    "Title: ",
                    item?.title
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                children: [
                    "Description: ",
                    item?.description
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                gap: "2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        flex: "1",
                        bg: "#000",
                        color: "#fff",
                        onClick: handle_approve_industry,
                        children: "Approve"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        flex: "1",
                        bg: "#fff",
                        color: "red",
                        border: "1px solid red",
                        onClick: handle_delete_industry,
                        children: "Delete"
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;