exports.id = 2388;
exports.ids = [2388];
exports.modules = {

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"authbody": "Home_authbody__DLl70",
	"filterbody": "Home_filterbody__B22Ud",
	"promotext": "Home_promotext__tLwGe",
	"loading": "Home_loading__IsZ5F",
	"div": "Home_div___Q0U8",
	"bounce": "Home_bounce___ruan",
	"promoimg": "Home_promoimg__BPdnz",
	"authsection1": "Home_authsection1__BPJNm",
	"productbody": "Home_productbody__jbcz1",
	"contactbody": "Home_contactbody__u3pjJ",
	"contactside": "Home_contactside__rfSNr",
	"consolebody": "Home_consolebody__5HoH_",
	"consoleNavigation": "Home_consoleNavigation__b6_XY",
	"Hub": "Home_Hub__i9ONv",
	"SigninBody": "Home_SigninBody__80gP8",
	"authSection": "Home_authSection__InFrC",
	"authForm": "Home_authForm__FaUSY",
	"productsection2": "Home_productsection2__Wgoc9",
	"consoleNavItem": "Home_consoleNavItem__4k5JR"
};


/***/ }),

/***/ 2126:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Get_Product)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

//import Cookies from 'universal-cookie';
async function Get_Product(payload) {
    const env = "production";
    console.log(env);
    if (env == "development") {
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("http://localhost:5001/api/get_product", payload);
        return result;
    } else if (env == "production") {
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://prokemia-adminserver-production.up.railway.app/api/get_product", payload);
        return result1;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;