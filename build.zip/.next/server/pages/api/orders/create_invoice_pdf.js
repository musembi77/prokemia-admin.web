"use strict";
(() => {
var exports = {};
exports.id = 1354;
exports.ids = [1354];
exports.modules = {

/***/ 605:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Create_Invoice_PDF)
});

;// CONCATENATED MODULE: external "easyinvoice"
const external_easyinvoice_namespaceObject = require("easyinvoice");
var external_easyinvoice_default = /*#__PURE__*/__webpack_require__.n(external_easyinvoice_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/orders/create_invoice_pdf.js

async function Create_Invoice_PDF(payload) {
    console.log(payload);
    create_invoice(payload);
}
const create_invoice = (payload)=>{
    const data = {
        // Customize enables you to provide your own templates
        // Please review the documentation for instructions and examples
        "customize": {
        },
        "images": {
            // The logo on top of your invoice
            logo: "https://res.cloudinary.com/musembi77/image/upload/v1671824849/ooa1dvpgz9relvhe6pfd.jpg"
        },
        // Your own data
        "sender": {
            "company": "Innovation Core Limited",
            "address": "Kibo street, Industrial Area",
            "zip": "Nairobi",
            "city": "Mobile: +254202525265",
            "country": "Pin: P051465357M"
        },
        // Your recipient
        "client": {
            "company": payload?.company_name_of_client,
            "address": payload?.name_of_client,
            "zip": payload?.email_of_client,
            "city": payload?.mobile_of_client,
            "country": payload?.location_of_client
        },
        "information": {
            // Invoice number
            "number": payload?._id,
            // Invoice data
            "date": payload?.createdAt,
            // Invoice due date
            "due-date": payload?.delivery_date
        },
        // The products you would like to see on your invoice
        // Total values are being calculated automatically
        "products": [
            {
                "quantity": payload?.volume_of_items,
                "description": payload?.name_of_product,
                "tax-rate": 16,
                "price": payload?.unit_price
            }
        ],
        // The message you would like to display on the bottom of your invoice
        "bottom-notice": `Terms:${payload?.delivery_terms}. Payment_Terms: ${payload?.payment_terms}. Make Payments to Innovation Core LTD, SBM BANK KENYA, ACC No.0082102124001, Riverside Branch`,
        // "bottom-notice": "Cash with Order.",
        // "bottom-notice": "Make Payments to Innovation Core LTD, SBM BANK KENYA, ACC No.0082102124001, Riverside Branch",
        // Settings to customize your invoice
        "settings": {
            "currency": "KES"
        },
        // Translate your invoice to your preferred language
        "translate": {
        }
    };
    try {
        console.log(data);
        external_easyinvoice_default().createInvoice(data, function(result) {
            //console.log(result);
            external_easyinvoice_default().download(`${payload?.company_name_of_client}.pdf`, result.pdf);
        });
    } catch (err) {
        console.log(err);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(605));
module.exports = __webpack_exports__;

})();