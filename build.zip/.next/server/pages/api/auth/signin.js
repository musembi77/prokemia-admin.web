"use strict";
(() => {
var exports = {};
exports.id = 4964;
exports.ids = [4964];
exports.modules = {

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 974:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SignIn)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6153);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function SignIn(payload) {
    /**
     * Sends a post req to submit user credentials to verify user.
     * 
     * env (): state of project.
     * result (obj): json res containing the token and status from server.
     * 
     * Return :
     *      Returns the result to Authhandler.
     * 
     */ const env = "production";
    //console.log(env)
    if (env == "development") {
        const end_point = process.env.DEV_API_ENDPOINT;
        const cookies = new (universal_cookie__WEBPACK_IMPORTED_MODULE_1___default())();
        const result = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`http://localhost:5001/api/signin`, payload);
        if (result.status === 201 || result.status === 500) {
            return result;
        } else {
            //console.log(result.data)
            cookies.set("admin_token", result.data, {
                path: "/"
            });
            return result;
        }
    } else if (env == "production") {
        const cookies1 = new (universal_cookie__WEBPACK_IMPORTED_MODULE_1___default())();
        const result1 = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://prokemia-adminserver-production.up.railway.app/api/signin`, payload);
        if (result1.status === 201 || result1.status === 500) {
            return result1;
        } else {
            //console.log(result.data)
            cookies1.set("admin_token", result1.data, {
                path: "/"
            });
            return result1;
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(974));
module.exports = __webpack_exports__;

})();